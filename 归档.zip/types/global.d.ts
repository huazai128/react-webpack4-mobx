declare module '*.scss' {
  const styles: any;
  export = styles;
}