export const STORE_TODO = 'todo';
export const STORE_ROUTER = 'router';
